This directory contains the Distutils package.

There's a full documentation available at:

    http://docs.python.org/distutils/

The Distutils-SIG web page is also a good starting point:

    http://www.python.org/sigs/distutils-sig/

WARNING : Distutils must remain compatible with 2.3

$Id$
